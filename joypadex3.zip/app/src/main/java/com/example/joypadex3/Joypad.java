package com.example.joypadex3;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

public class Joypad {
    public static final int NONE = 0;
    public static final int UP = 1;
    public static final int RIGHT = 2;
    public static final int DOWN = 3;
    public static final int LEFT = 4;

    private int CURSOR_ALPHA = 200;
    private int LAYOUT_ALPHA = 200;
    private int OFFSET = 0;

    private Context mContext;
    private ViewGroup mLayout;
    private ViewGroup.LayoutParams params;
    private int cursorWidth, cursorHeight;
    private boolean touchState = false;

    private int posX = 0, posY = 0, min = 0;
    private float distance = 0, angle = 0;

    private DrawCanvas drawCanvas;
    private Paint paint;
    private Bitmap cursor;

    public Joypad(Context context, ViewGroup layout, int cursorImg) {
        mContext = context;

        cursor = BitmapFactory.decodeResource(mContext.getResources(), cursorImg);
        cursorWidth = cursor.getWidth();
        cursorHeight = cursor.getHeight();

        drawCanvas = new DrawCanvas(mContext);
        paint = new Paint();
        mLayout = layout;
        params = mLayout.getLayoutParams();
    }

    public void drawPad(MotionEvent arg1) {
        posX = (int) (arg1.getX() - (params.width / 2));
        posY = (int) (arg1.getY() - (params.width / 2));
        distance = (float) Math.sqrt(Math.pow(posX, 2) + Math.pow(posY, 2));
        angle = (float) calculateAngle(posX, posY);

        if (arg1.getAction() == MotionEvent.ACTION_DOWN) {
            if (distance <= (params.width / 2f) - OFFSET) {
                drawCanvas.position(arg1.getX(), arg1.getY());
                draw();
                touchState = true;
            }
        } else if (arg1.getAction() == MotionEvent.ACTION_MOVE && touchState) {
            if (distance <= (params.width / 2f) - OFFSET) {
                drawCanvas.position(arg1.getX(), arg1.getY());
                draw();
            } else if (distance > (params.width / 2f) - OFFSET) {
                float x = (float) (Math.cos(Math.toRadians(calculateAngle(posX, posY))) * ((params.width / 2) - OFFSET));
                float y = (float) (Math.sin(Math.toRadians(calculateAngle(posX, posY))) * ((params.height / 2) - OFFSET));
                x += (params.width / 2f);
                y += (params.height / 2f);
                drawCanvas.position(x, y);
                draw();
            } else {
                mLayout.removeView(drawCanvas);
            }
        } else if (arg1.getAction() == MotionEvent.ACTION_UP) {
            mLayout.removeView(drawCanvas);
            touchState = false;
        }
    }

    public int[] getPos() {
        if (distance > min && touchState) {
            return new int[]{posX, posY};
        }
        return new int[]{0, 0};
    }

    public int getX() {
        if (distance > min && touchState) {
            return posX;
        }
        return 0;
    }

    public int getY() {
        if (distance > min && touchState) {
            return posY;
        }
        return 0;
    }

    public float getAngle() {
        if (distance > min && touchState) {
            return angle;
        }
        return 0;
    }

    public float getDistance() {
        if (distance > min && touchState) {
            return distance;
        }
        return 0;
    }

    public void setMinimumDistance(int minDistance) {
        min = minDistance;
    }

    public int getMinimumDistance() {
        return min;
    }

    public void setOffset(int offset) {
        OFFSET = offset;
    }

    public int getOffset() {
        return OFFSET;
    }

    public void setCursorAlpha(int alpha) {
        CURSOR_ALPHA = alpha;
        paint.setAlpha(alpha);
    }

    public int getCursorAlpha() {
        return CURSOR_ALPHA;
    }

    public void setLayoutAlpha(int alpha) {
        LAYOUT_ALPHA = alpha;
        mLayout.getBackground().setAlpha(alpha);
    }

    public void setCursorWidth(int width) {
        cursor = Bitmap.createScaledBitmap(cursor, width, cursorHeight, false);
        cursorWidth = cursor.getWidth();
    }

    public void setCursorHeight(int height) {
        cursor = Bitmap.createScaledBitmap(cursor, cursorWidth, height, false);
        cursorHeight = cursor.getHeight();
    }

    public int getCursorWidth() {
        return cursorWidth;
    }

    public int getCursorHeight() {
        return cursorHeight;
    }

    public void setLayoutSize(int width, int height) {
        params.width = width;
        params.height = height;
    }

    public void setCursorSize(int width, int height) {
        cursor = Bitmap.createScaledBitmap(cursor, width, height, false);
        cursorWidth = cursor.getWidth();
        cursorHeight = cursor.getHeight();
    }

    public int getLayoutWidth() {
        return params.width;
    }

    public int getLayoutHeight() {
        return params.height;
    }

    public int get4Direction() {
        if (distance > min && touchState) {
            if (angle >= 225 && angle < 315) {
                return UP;
            } else if (angle >= 315 || angle < 45) {
                return RIGHT;
            } else if (angle >= 45 && angle < 135) {
                return DOWN;
            } else if (angle >= 135 && angle < 225) {
                return LEFT;
            }
        } else if (distance <= min && touchState) {
            return NONE;
        }
        return 0;
    }

    private double calculateAngle(float x, float y) {
        if (x >= 0 && y >= 0)
            return Math.toDegrees(Math.atan(y / x));
        else if (x < 0 && y >= 0)
            return Math.toDegrees(Math.atan(y / x)) + 180;
        else if (x < 0 && y < 0)
            return Math.toDegrees(Math.atan(y / x)) + 180;
        else if (x >= 0 && y < 0)
            return Math.toDegrees(Math.atan(y / x)) + 360;
        return 0;
    }

    private void draw() {
        try {
            mLayout.removeView(drawCanvas);
        } catch (Exception ignored) {
        }
        mLayout.addView(drawCanvas);
    }

    private class DrawCanvas extends View {
        float x, y;

        public DrawCanvas(Context context) {
            super(context);
        }

        public void onDraw(Canvas canvas) {
            canvas.drawBitmap(cursor, x, y, paint);
        }

        private void position(float pos_x, float pos_y) {
            x = pos_x - (cursorWidth / 2f);
            y = pos_y - (cursorHeight / 2f);
        }
    }

}
