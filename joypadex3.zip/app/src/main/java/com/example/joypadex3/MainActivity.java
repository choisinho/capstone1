package com.example.joypadex3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RelativeLayout joypad;
    TextView tvAngle, tvDistance, tvDirection;
    Button next;

    Joypad jp;

    @Override
    @SuppressLint("ClickableViewAccessibility")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvAngle = (TextView) findViewById(R.id.tv_angle);
        tvDistance = (TextView) findViewById(R.id.tv_distance);
        tvDirection = (TextView) findViewById(R.id.tv_direction);

        joypad = (RelativeLayout) findViewById(R.id.joypad);

        jp = new Joypad(getApplicationContext(), joypad, R.drawable.ic_baseline_adjust_24);
        jp.setCursorSize(150, 150);
        jp.setLayoutSize(500, 500);
        jp.setLayoutAlpha(150);
        jp.setCursorAlpha(100);
        jp.setOffset(90);
        jp.setMinimumDistance(50);

        joypad.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1) {
                jp.drawPad(arg1);
                if (arg1.getAction() == MotionEvent.ACTION_DOWN
                        || arg1.getAction() == MotionEvent.ACTION_MOVE) {
                    tvAngle.setText("각도 : " + String.valueOf(jp.getAngle()));
                    tvDirection.setText("방향 : " + String.valueOf(jp.getDistance()));

                    int direction = jp.get4Direction();
                    if (direction == jp.UP) {
                        tvDirection.setText("방향 : 위");
                    } else if (direction == jp.DOWN) {
                        tvDirection.setText("방향 : 아래");
                    } else if (direction == jp.RIGHT) {
                        tvDirection.setText("방향 : 오른쪽");
                    } else if (direction == jp.LEFT) {
                        tvDirection.setText("방향 : 왼쪽");
                    }
                } else if (arg1.getAction() == MotionEvent.ACTION_UP) {
                    tvAngle.setText("각도 :");
                    tvDistance.setText("거리 :");
                    tvDirection.setText("방향 :");
                }
                return true;
            }
        });
    }
}